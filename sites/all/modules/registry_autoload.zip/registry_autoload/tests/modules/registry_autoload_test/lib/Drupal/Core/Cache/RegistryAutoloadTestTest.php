<?php
/**
 * @file
 * Tests that PSR-0 namespaced classes get registered correctly.
 */

namespace Drupal\Core\Cache;

class RegistryAutoloadTestTest {
  /**
   * Constructs a RegistryAutoloadTestTest object.
   */
  public function __construct() {
    print "Hello Core\n";
  }
}
