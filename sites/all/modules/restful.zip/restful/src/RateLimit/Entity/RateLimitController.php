<?php

/**
 * @file
 * Contains Drupal\restful\RateLimit\Entity\RateLimitController.
 */

namespace Drupal\restful\RateLimit\Entity;

class RateLimitController extends \EntityAPIController {}
