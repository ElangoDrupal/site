<?php

/**
 * @file
 * Contains \Drupal\restful\Plugin\resource\DataInterpreter\DataInterpreterPlug.
 */

namespace Drupal\restful\Plugin\resource\DataInterpreter;

class DataInterpreterPlug extends DataInterpreterBase implements DataInterpreterInterface {}
