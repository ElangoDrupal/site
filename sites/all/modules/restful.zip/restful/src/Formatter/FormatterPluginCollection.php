<?php

/**
 * @file
 * Contains \Drupal\restful\Formatter\FormatterPluginCollection
 */

namespace Drupal\restful\Formatter;

use Drupal\Core\Plugin\DefaultLazyPluginCollection;

class FormatterPluginCollection extends DefaultLazyPluginCollection {}
