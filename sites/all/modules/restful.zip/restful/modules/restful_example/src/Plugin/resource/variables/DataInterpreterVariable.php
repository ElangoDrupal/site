<?php

/**
 * @file
 * Contains \Drupal\restful_example\Plugin\resource\variables\DataInterpreterVariable.
 */

namespace Drupal\restful_example\Plugin\resource\variables;

use Drupal\restful\Plugin\resource\DataInterpreter\DataInterpreterBase;

class DataInterpreterVariable extends DataInterpreterBase {}
