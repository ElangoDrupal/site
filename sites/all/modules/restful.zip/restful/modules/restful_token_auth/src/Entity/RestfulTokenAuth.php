<?php

/**
 * @file
 * Contains Drupal\restful_token_auth\Entity\RestfulTokenAuth.
 */

namespace Drupal\restful_token_auth\Entity;

class RestfulTokenAuth extends \Entity {}
