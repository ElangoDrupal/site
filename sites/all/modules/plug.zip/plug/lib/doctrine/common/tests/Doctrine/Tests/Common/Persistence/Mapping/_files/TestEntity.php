<?php

$metadata->getFieldNames();