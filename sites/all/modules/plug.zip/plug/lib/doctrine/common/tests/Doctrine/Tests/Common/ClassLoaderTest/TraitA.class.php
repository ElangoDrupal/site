<?php

trait ClassLoaderTest_TraitA
{
}
