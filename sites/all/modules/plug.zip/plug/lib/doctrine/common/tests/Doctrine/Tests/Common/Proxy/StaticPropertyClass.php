<?php

namespace Doctrine\Tests\Common\Proxy;

/**
 * Test asset class
 */
class StaticPropertyClass
{
    protected static $protectedStaticProperty;
}
